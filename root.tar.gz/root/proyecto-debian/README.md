#AQUI VAN A IR LAS ANOTACIONES DEL TP DE COMPUTACION

#TRABAJO PRACTICO INTEGRADOR- COMPUTACION APLICADA-UP

-Ezquiel Cirigliano
-Franco Nahuel Morrone
-Gaudalupe Castro
-Guillermina Castaño

#Estructura del repositorio
- '/etc.atr-gz' configuracion del sistema
- '/root.tar-gz' Archivo del usuario root
- '/opt.tar.gz' Script de backup
- '/www_dr.tar.gz' Contenido web del servidor
- '"backup_dr.tar.gz' Backups Generados
- 'var_part_*' Directorio /var dividido por tamaños
- 'diagrama_topologico.png' Diagrama  Visual de la infraestructura

#Copmo probrar el entorno
1. Importar la maquina Virtual en VirtualBox
2. Arrancar el sistema y loguerse como root (clave : palermo)
3. Verificar los servicios:
	- SSH 'ssh root@IP'
	- Apache: Navegar a 'http://IP'
	- MariaDB: 'mysql -u root -p'
4. Resvisar el script /opt/scripts/backup_full.sh' y ejecutarlo manual o automaticamente con 'cron'
