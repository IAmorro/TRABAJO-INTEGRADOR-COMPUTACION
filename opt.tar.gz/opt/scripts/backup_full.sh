#!/bin/bash

if [[ "$1" == "--help" ]]; then
	echo "Uso :  $0 <origin> <destinp>"
	exit 0
fi

if [[ $# -ne 2 ]]; then
	echo"EROOR : DEBEN DE HABER 2 ARGUMENTOS"
	exit 1
fi
ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)

NOMBRE_BACKUP=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz

if [[ ! -d "$ORIGEN" ]]; then
	echo"EROOR DIRECTORIO O ORIGEN INCORRECTO"
	exit 2
fi
tar -czf "$DESTINO/$NOMBRE_BACKUP" "$ORIGEN"

if [[ $? -eq 0 ]]; then
	echo "Backup exitoso $DESTINO/$NOMBRE_BACKUP"
else
	echo "Error al crear el backup"
	exit 4
fi
